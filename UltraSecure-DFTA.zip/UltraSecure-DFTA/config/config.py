import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

WATCH_FOLDER = r"C:\Users\kadal\Desktop\test_files"
HASH_ALGO = "SHA256"

UPLOAD_FOLDER = os.path.join(BASE_DIR, "..", "uploads")
LOG_FOLDER = os.path.join(BASE_DIR, "..", "logs")
BACKUP_FOLDER = os.path.join(BASE_DIR, "..", "backups")

ALLOWED_EXTENSIONS = ["txt", "pdf", "png", "jpg", "jpeg", "exe"]  # <-- ADD THIS

for folder in [UPLOAD_FOLDER, LOG_FOLDER, BACKUP_FOLDER]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# ------------------ ENCRYPTION SETTINGS ------------------
ENCRYPTION_KEY = b's04_SRJISaFxIbAEEwbBqF6kkMRC8hIjFvls3pOOK84='

# ------------------ EMAIL ALERT SETTINGS ------------------
EMAIL_ALERTS = False
EMAIL_HOST = "smtp.gmail.com"
EMAIL_PORT = 587
EMAIL_USER = "example@gmail.com"
EMAIL_PASS = "password_here"
