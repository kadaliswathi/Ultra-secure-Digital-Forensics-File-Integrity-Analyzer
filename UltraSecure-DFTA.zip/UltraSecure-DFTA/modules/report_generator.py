import os
from fpdf import FPDF
from datetime import datetime
from modules.screenshot import ScreenShot

REPORT_FOLDER = "reports"

if not os.path.exists(REPORT_FOLDER):
    os.makedirs(REPORT_FOLDER)


class ReportGenerator:

    @staticmethod
    def generate_pdf_report(results):
        filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = os.path.join(REPORT_FOLDER, filename)

        # Take screenshot safely
        screenshot_path = ScreenShot.take("File Integrity Verification")

        pdf = FPDF()
        pdf.add_page()

        # ----------------------------------------------------
        # HEADER
        # ----------------------------------------------------
        pdf.set_font("Arial", "B", 20)
        pdf.set_text_color(0, 51, 102)   # dark blue
        pdf.cell(0, 12, "UltraSecure - Digital Forensic Report", ln=True, align="C")

        pdf.set_font("Arial", "", 12)
        pdf.set_text_color(80, 80, 80)
        pdf.cell(0, 8, f"Generated On: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}", ln=True, align="C")

        pdf.ln(10)

        # ----------------------------------------------------
        # SUMMARY SECTION
        # ----------------------------------------------------
        total_files = len(results)
        modified = sum(1 for x in results.values() if x == "MODIFIED")
        safe = total_files - modified

        pdf.set_font("Arial", "B", 14)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 10, "Summary Report:", ln=True)

        pdf.set_font("Arial", "", 12)
        pdf.cell(0, 8, f"Total Files Scanned : {total_files}", ln=True)
        pdf.cell(0, 8, f"Safe Files          : {safe}", ln=True)
        pdf.cell(0, 8, f"Modified Files      : {modified}", ln=True)

        pdf.ln(10)

        # ----------------------------------------------------
        # TABLE HEADER
        # ----------------------------------------------------
        pdf.set_font("Arial", "B", 12)
        pdf.set_fill_color(200, 220, 255)
        pdf.cell(120, 10, "File Name", border=1, align="C", fill=True)
        pdf.cell(70, 10, "Status", border=1, align="C", fill=True)
        pdf.ln()

        # ----------------------------------------------------
        # TABLE ROWS
        # ----------------------------------------------------
        pdf.set_font("Arial", "", 11)

        for file, status in results.items():

            # Green for SAFE, Red for MODIFIED
            if status == "MODIFIED":
                pdf.set_text_color(200, 0, 0)  # red
            else:
                pdf.set_text_color(0, 130, 0)  # green

            pdf.cell(120, 10, file, border=1)
            pdf.cell(70, 10, status, border=1)
            pdf.ln()

        pdf.set_text_color(0, 0, 0)

        pdf.ln(10)

        # ----------------------------------------------------
        # SCREENSHOT SECTION
        # ----------------------------------------------------
        pdf.set_font("Arial", "B", 14)
        pdf.cell(0, 10, "Screenshot Captured:", ln=True)

        if screenshot_path and os.path.exists(screenshot_path):
            try:
                pdf.image(screenshot_path, x=10, w=180)
            except:
                pdf.set_font("Arial", "", 12)
                pdf.cell(0, 10, "Screenshot could not be embedded.", ln=True)
        else:
            pdf.set_font("Arial", "", 12)
            pdf.cell(0, 10, "No screenshot available.", ln=True)

        pdf.output(filepath)
        print(f"[PDF GENERATED SUCCESSFULLY] {filepath}")
        return filepath
