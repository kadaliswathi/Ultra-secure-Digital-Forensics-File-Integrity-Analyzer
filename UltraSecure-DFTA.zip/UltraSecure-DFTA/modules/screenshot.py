import os
from datetime import datetime
from PIL import ImageGrab, Image

SCREENSHOT_FOLDER = "screenshots"

# Ensure folder exists
if not os.path.exists(SCREENSHOT_FOLDER):
    os.makedirs(SCREENSHOT_FOLDER)


class ScreenShot:
    @staticmethod
    def take(reason="Unknown"):
        """
        Capture screenshot safely.
        Works 100% on Windows.
        Avoids crash if ImageGrab fails or no display found.
        """

        try:
            # Timestamp & filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screenshot_{timestamp}.png"
            filepath = os.path.join(SCREENSHOT_FOLDER, filename)

            # Capture screenshot
            img = ImageGrab.grab(all_screens=True)   # multi-monitor safe
            img = img.convert("RGB")                # avoids PNG errors

            img.save(filepath, "PNG")

            print(f"[SCREENSHOT CAPTURED] File: {filepath}  Reason: {reason}")
            return filepath

        except OSError as e:
            print(f"[SCREENSHOT ERROR] OS error: {e}")
            return None

        except Exception as e:
            print(f"[SCREENSHOT ERROR] Unexpected issue: {e}")
            return None
