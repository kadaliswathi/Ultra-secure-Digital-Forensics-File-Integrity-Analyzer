import hashlib
import os
import json

BASELINE_DB = "baseline.json"

class FileIntegrity:

    @staticmethod
    def get_hash(path):
        hasher = hashlib.sha256()
        with open(path, "rb") as f:
            hasher.update(f.read())
        return hasher.hexdigest()

    @staticmethod
    def check_file(path):
        file_hash = FileIntegrity.get_hash(path)

        if not os.path.exists(BASELINE_DB):
            with open(BASELINE_DB, "w") as f:
                json.dump({}, f)

        with open(BASELINE_DB, "r") as f:
            data = json.load(f)

        filename = os.path.basename(path)

        if filename not in data:
            print(f"[BASELINE] Adding new file {filename}")
            data[filename] = file_hash
        else:
            if data[filename] != file_hash:
                print(f"[ALERT] File modified: {filename}")
            else:
                print(f"[OK] File unchanged: {filename}")

        with open(BASELINE_DB, "w") as f:
            json.dump(data, f)

        return True
