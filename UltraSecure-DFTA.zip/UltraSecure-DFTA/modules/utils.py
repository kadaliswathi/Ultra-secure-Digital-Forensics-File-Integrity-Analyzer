import os
import shutil
import smtplib
from email.message import EmailMessage
from datetime import datetime
from cryptography.fernet import Fernet
from config.config import BACKUP_FOLDER, EMAIL_ALERTS, EMAIL_HOST, EMAIL_PORT, EMAIL_USER, EMAIL_PASS, ENCRYPTION_KEY

def ensure_folder(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

# Ensure backup folder exists when module imported
ensure_folder(BACKUP_FOLDER)

# Encryption key handling: use config key if provided, otherwise generate a temporary key
if ENCRYPTION_KEY:
    _FERNET_KEY = ENCRYPTION_KEY
else:
    # generate a key (will change each run unless you set ENCRYPTION_KEY in config)
    _FERNET_KEY = Fernet.generate_key()
fernet = Fernet(_FERNET_KEY)

def encrypt_file(filepath):
    with open(filepath, 'rb') as f:
        data = f.read()
    encrypted = fernet.encrypt(data)
    out = filepath + '.enc'
    with open(out, 'wb') as f:
        f.write(encrypted)
    return out

def decrypt_file(enc_filepath):
    with open(enc_filepath, 'rb') as f:
        data = f.read()
    decrypted = fernet.decrypt(data)
    out = enc_filepath.replace('.enc', '')
    with open(out, 'wb') as f:
        f.write(decrypted)
    return out

def send_email_alert(subject, body, attachment=None):
    if not EMAIL_ALERTS:
        return
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = EMAIL_USER
    msg['To'] = EMAIL_USER
    msg.set_content(body)
    if attachment and os.path.exists(attachment):
        with open(attachment, 'rb') as f:
            file_data = f.read()
            file_name = os.path.basename(attachment)
        msg.add_attachment(file_data, maintype='application', subtype='octet-stream', filename=file_name)
    with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASS)
        server.send_message(msg)

def backup_folder(folder_path):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_name = os.path.join(BACKUP_FOLDER, f"backup_{timestamp}")
    shutil.make_archive(base_name, 'zip', folder_path)
    return base_name + '.zip'
