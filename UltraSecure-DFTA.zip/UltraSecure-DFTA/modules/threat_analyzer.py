import os
import shutil
import smtplib
from email.message import EmailMessage
from datetime import datetime
from cryptography.fernet import Fernet
from config.config import (
    BACKUP_FOLDER,
    EMAIL_ALERTS,
    EMAIL_HOST,
    EMAIL_PORT,
    EMAIL_USER,
    EMAIL_PASS,
    ENCRYPTION_KEY,
)
from modules.utils import ensure_folder

# Ensure backup folder exists
ensure_folder(BACKUP_FOLDER)

# Encryption key handling
if ENCRYPTION_KEY:
    _FERNET_KEY = ENCRYPTION_KEY
else:
    _FERNET_KEY = Fernet.generate_key()

fernet = Fernet(_FERNET_KEY)


class ThreatAnalyzer:

    @staticmethod
    def scan_file(filepath):
        """Basic threat scan simulation."""
        if not os.path.exists(filepath):
            print(f"[ERROR] File not found: {filepath}")
            return

        # Simple extension based threat simulation
        ext = os.path.splitext(filepath)[1].lower()

        if ext in [".exe", ".bat", ".cmd", ".ps1"]:
            print(f"[THREAT] Suspicious executable detected: {filepath}")
            ThreatAnalyzer.backup_and_alert(filepath)
        else:
            print(f"[SAFE] No threat found: {filepath}")

    @staticmethod
    def scan_folder(folder=None):
        """Scan entire folder for dangerous files."""
        if folder is None:
            folder = BACKUP_FOLDER

        print(f"[SCAN] Scanning folder: {folder}")

        for root, dirs, files in os.walk(folder):
            for file in files:
                filepath = os.path.join(root, file)
                ThreatAnalyzer.scan_file(filepath)

    @staticmethod
    def backup_and_alert(filepath):
        """Backup, encrypt, and send alert."""
        # Backup
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(BACKUP_FOLDER, f"backup_{timestamp}.zip")
        shutil.make_archive(backup_path.replace(".zip", ""), "zip", os.path.dirname(filepath))
        print(f"[BACKUP] Backup created: {backup_path}")

        # Encrypt file
        enc_file = ThreatAnalyzer.encrypt_file(filepath)
        print(f"[ENCRYPTED] File encrypted: {enc_file}")

        # Email alert
        ThreatAnalyzer.send_email_alert(
            subject="Threat Detected",
            body=f"A suspicious file was detected and processed:\n{filepath}",
            attachment=enc_file,
        )

    @staticmethod
    def encrypt_file(filepath):
        with open(filepath, "rb") as f:
            data = f.read()
        encrypted = fernet.encrypt(data)
        out = filepath + ".enc"
        with open(out, "wb") as f:
            f.write(encrypted)
        return out

    @staticmethod
    def send_email_alert(subject, body, attachment=None):
        if not EMAIL_ALERTS:
            print("[EMAIL] Alerts disabled.")
            return

        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = EMAIL_USER
        msg["To"] = EMAIL_USER
        msg.set_content(body)

        if attachment and os.path.exists(attachment):
            with open(attachment, "rb") as f:
                file_data = f.read()
            msg.add_attachment(
                file_data,
                maintype="application",
                subtype="octet-stream",
                filename=os.path.basename(attachment),
            )

        try:
            with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
                server.starttls()
                server.login(EMAIL_USER, EMAIL_PASS)
                server.send_message(msg)
            print("[EMAIL] Alert sent successfully.")
        except Exception as e:
            print("[EMAIL ERROR]", e)
