import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from modules.file_integrity import FileIntegrity
from modules.threat_analyzer import ThreatAnalyzer

class MonitorHandler(FileSystemEventHandler):
    
    def on_modified(self, event):
        if not event.is_directory:
            print(f"[MODIFIED] {event.src_path}")
            FileIntegrity.check_file(event.src_path)
            ThreatAnalyzer.scan_file(event.src_path)

    def on_created(self, event):
        if not event.is_directory:
            print(f"[CREATED] {event.src_path}")
            FileIntegrity.check_file(event.src_path)
            ThreatAnalyzer.scan_file(event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            print(f"[DELETED] {event.src_path}")


class FolderMonitor:

    @staticmethod
    def start(folder):
        print(f"Monitoring started in: {folder}")
        event_handler = MonitorHandler()
        observer = Observer()
        observer.schedule(event_handler, folder, recursive=True)
        observer.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()

        observer.join()
