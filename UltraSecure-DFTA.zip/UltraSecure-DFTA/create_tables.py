import sqlite3, os

# Create required folders
os.makedirs("uploads", exist_ok=True)
os.makedirs("reports", exist_ok=True)

# Connect to database
conn = sqlite3.connect("users.db")
cur = conn.cursor()

# ---------------- USERS TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT,
    approved INTEGER DEFAULT 0
)
""")

# Default Admin User
cur.execute("SELECT * FROM users WHERE username='admin'")
if not cur.fetchone():
    cur.execute(
        "INSERT INTO users (username, password, role, approved) VALUES (?,?,?,?)",
        ("admin", "admin123", "admin", 1)
    )


# ---------------- FILE UPLOADS TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS file_records (
    file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    file_name TEXT,
    file_path TEXT,
    uploaded_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")


# ---------------- FILE INTEGRITY LOGS ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS file_integrity (
    integrity_id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER,
    old_hash TEXT,
    new_hash TEXT,
    status TEXT,
    last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(file_id) REFERENCES file_records(file_id)
)
""")


# ---------------- REPORTS TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS reports (
    report_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    report_name TEXT,
    report_path TEXT,
    created_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

conn.commit()
conn.close()

print("✔ Database (users.db) created successfully!")
print("✔ Tables created successfully!")
print("✔ Default admin added (admin / admin123)")
