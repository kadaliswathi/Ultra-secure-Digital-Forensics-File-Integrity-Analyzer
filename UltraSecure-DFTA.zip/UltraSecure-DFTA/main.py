import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from modules.file_integrity import FileIntegrity
from modules.report_generator import ReportGenerator
from modules.threat_analyzer import ThreatAnalyzer
from modules.folder_monitor import FolderMonitor
from modules.screenshot import ScreenShot   # <-- ADDED
import threading
import os


def run_gui():
    root = tk.Tk()
    root.title("UltraSecure DFTA 2025")
    root.state("zoomed")
    root.configure(bg="#2C3E50")

    # ---------------- Background Image ----------------
    try:
        from PIL import Image, ImageTk
        bg_image = Image.open("background.jpg")
        bg_image = bg_image.resize((root.winfo_screenwidth(), root.winfo_screenheight()))
        bg_photo = ImageTk.PhotoImage(bg_image)
        bg_label = tk.Label(root, image=bg_photo)
        bg_label.place(relwidth=1, relheight=1)
        bg_label.lower()
    except:
        pass

    # ---------------- Header ----------------
    tk.Label(root,
             text="🛡️ UltraSecure Digital Forensics Analyzer",
             font=("Segoe UI", 22, "bold"),
             bg="#2C3E50", fg="#F1C40F").pack(pady=20)

    # ---------------- Folder Input ----------------
    frame = tk.Frame(root, bg="#2C3E50")
    frame.pack(pady=10)

    tk.Label(frame, text="Select Folder:", font=("Segoe UI", 14),
             bg="#2C3E50", fg="white").grid(row=0, column=0, padx=5)

    entry_folder = tk.Entry(frame, width=60, font=("Segoe UI", 12))
    entry_folder.grid(row=0, column=1, padx=5)

    def choose_folder():
        folder = filedialog.askdirectory()
        if folder:
            entry_folder.delete(0, tk.END)
            entry_folder.insert(0, folder)

    tk.Button(frame, text="Browse 📁",
              command=choose_folder,
              bg="#2980B9", fg="white",
              font=("Segoe UI", 12, "bold")).grid(row=0, column=2, padx=5)

    # ---------------- Status ----------------
    status_label = tk.Label(root, text="", font=("Segoe UI", 13),
                            bg="#2C3E50", fg="#1ABC9C")
    status_label.pack(pady=5)

    # ---------------- Thread Runner ----------------
    def run_threaded(func, *args):
        threading.Thread(target=func, args=args, daemon=True).start()

    # ===================================================
    #  BASELINE SCAN
    # ===================================================
    def baseline_scan():
        folder = entry_folder.get()
        if not folder:
            messagebox.showerror("Error", "Please select a folder!")
            return
        status_label.config(text="🔄 Creating baseline...")
        run_threaded(run_baseline, folder)

    def run_baseline(folder):
        for root_dir, dirs, files in os.walk(folder):
            for file in files:
                path = os.path.join(root_dir, file)
                FileIntegrity.check_file(path)

        # TAKE SCREENSHOT
        ScreenShot.take("Baseline Scan Completed")

        status_label.config(text="✅ Baseline created successfully!")

    # ===================================================
    #  VERIFY INTEGRITY
    # ===================================================
    def verify_scan():
        folder = entry_folder.get()
        if not folder:
            messagebox.showerror("Error", "Please select a folder!")
            return
        status_label.config(text="🔄 Checking integrity...")
        run_threaded(run_verify, folder)

    def run_verify(folder):
        results = {}
        for root_dir, dirs, files in os.walk(folder):
            for file in files:
                path = os.path.join(root_dir, file)
                FileIntegrity.check_file(path)
                results[file] = "Verified"

        ReportGenerator().generate_pdf_report(results)

        # SCREENSHOT
        ScreenShot.take("Verify Integrity Completed")

        status_label.config(text="✅ Integrity Verified — PDF Generated!")

    # ===================================================
    #  THREAT SCAN
    # ===================================================
    def scan_threats():
        folder = entry_folder.get()
        if not folder:
            messagebox.showerror("Error", "Please select a folder!")
            return
        status_label.config(text="🛡️ Scanning for threats...")
        run_threaded(run_threat_scan, folder)

    def run_threat_scan(folder):
        ThreatAnalyzer.scan_folder(folder)

        # SCREENSHOT
        ScreenShot.take("Threat Scan Completed")

        status_label.config(text="✅ Threat Scan Completed!")

    # ===================================================
    #  START MONITOR
    # ===================================================
    def start_monitor():
        folder = entry_folder.get()
        if not folder:
            messagebox.showerror("Error", "Please select a folder!")
            return
        status_label.config(text="⏱️ Monitoring started...")

        # SCREENSHOT
        ScreenShot.take("Folder Monitor Started")

        run_threaded(lambda: FolderMonitor.start(folder))

    # ---------------- Buttons ----------------
    btn_frame = tk.Frame(root, bg="#2C3E50")
    btn_frame.pack(pady=15)

    options = [
        ("Create Baseline 🔑", baseline_scan, "#27AE60"),
        ("Verify Integrity 🔍", verify_scan, "#2980B9"),
        ("Scan Threats ⚠️", scan_threats, "#C0392B"),
        ("Start Folder Monitor ⏱️", start_monitor, "#8E44AD"),
    ]

    for text, func, color in options:
        btn = tk.Button(btn_frame, text=text, command=func,
                        bg=color, fg="white",
                        width=30, font=("Segoe UI", 12, "bold"))
        btn.pack(pady=6)

    # ---------------- Output Logs ----------------
    log_frame = tk.LabelFrame(root, text="Logs", bg="#34495E",
                              fg="white", font=("Segoe UI", 12, "bold"))
    log_frame.pack(padx=20, pady=10, fill="both", expand=True)

    log_box = scrolledtext.ScrolledText(log_frame, bg="#1C2833",
                                        fg="white", font=("Consolas", 11))
    log_box.pack(fill="both", expand=True)

    # Redirect Output
    import sys

    class Redirect:
        def write(self, s):
            log_box.insert(tk.END, s)
            log_box.see(tk.END)
        def flush(self):
            pass

    sys.stdout = Redirect()
    sys.stderr = Redirect()

    root.mainloop()


if __name__ == "__main__":
    run_gui()
