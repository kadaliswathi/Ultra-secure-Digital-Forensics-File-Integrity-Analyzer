import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, flash

# ----------------------------- FLASK SETUP -----------------------------
app = Flask(__name__)
app.secret_key = "UltraSecureAdminSecretKey123"

# ----------------------------- FOLDERS -----------------------------
WATCH_FOLDER = "uploads"
REPORT_FOLDER = "reports"
BACKUP_FOLDER = "backups"

for folder in [WATCH_FOLDER, REPORT_FOLDER, BACKUP_FOLDER]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# ----------------------------- ALLOWED FILES -----------------------------
ALLOWED_EXTENSIONS = ['txt', 'pdf', 'docx', 'png', 'jpg', 'jpeg']

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ----------------------------- DATABASE -----------------------------
DB_PATH = "users.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                approved INTEGER DEFAULT 0
            )
        """)
        conn.commit()

init_db()

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    return conn


# =====================================================================
#                              USER LOGIN
# =====================================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form["username"]
        p = request.form["password"]

        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username=? AND password=?", (u, p))
            user = cur.fetchone()

        if user:
            if user["approved"] == 0:
                return render_template("login.html", error="Your account is not approved yet!")

            session["username"] = user["username"]
            session["role"] = user["role"]

            if user["role"] == "admin":
                return redirect(url_for("admin_dashboard"))
            return redirect(url_for("index"))

        return render_template("login.html", error="Invalid username or password")

    return render_template("login.html")


# =====================================================================
#                             USER REGISTER
# =====================================================================
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u = request.form["username"]
        p = request.form["password"]

        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute("INSERT INTO users (username, password) VALUES (?, ?)", (u, p))
                conn.commit()
            flash("Registration successful! Wait for Admin approval.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            return render_template("register.html", error="Username already exists")

    return render_template("register.html")


# =====================================================================
#                              USER LOGOUT
# =====================================================================
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# =====================================================================
#                              USER HOME
# =====================================================================
@app.route("/", methods=["GET", "POST"])
def index():
    if "username" not in session:
        return redirect(url_for("login"))

    msg = ""

    if request.method == "POST":
        if "file" not in request.files:
            msg = "No file selected"
        else:
            file = request.files["file"]
            if file.filename == "":
                msg = "No file selected"
            elif allowed_file(file.filename):
                filepath = os.path.join(WATCH_FOLDER, file.filename)
                file.save(filepath)
                msg = f"File uploaded & scanned: {file.filename}"
            else:
                msg = "Invalid file type"

    return render_template("index.html", message=msg)


# =====================================================================
#                        REPORT DASHBOARD
# =====================================================================
@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    reports = [f for f in os.listdir(REPORT_FOLDER) if f.endswith(".pdf")]
    return render_template("dashboard.html", reports=reports)


@app.route("/reports/<filename>")
def download_report(filename):
    return send_from_directory(REPORT_FOLDER, filename, as_attachment=True)


# =====================================================================
#                          ADMIN LOGIN
# =====================================================================
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        u = request.form["username"]
        p = request.form["password"]

        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username=? AND password=?", (u, p))
            user = cur.fetchone()

        if user and user["role"] == "admin":
            session["admin"] = u
            return redirect(url_for("admin_dashboard"))

        return render_template("admin_login.html", error="Invalid Admin credentials")

    return render_template("admin_login.html")


# =====================================================================
#                          ADMIN DASHBOARD
# =====================================================================
@app.route("/admin/dashboard")
def admin_dashboard():
    if "admin" not in session:
        return redirect(url_for("admin_login"))

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM users")
        users = cur.fetchall()

    return render_template("admin_dashboard.html", users=users)


# =====================================================================
#                       ADMIN ACTIONS
# =====================================================================
@app.route("/admin/approve/<username>")
def approve_user(username):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET approved=1 WHERE username=?", (username,))
        conn.commit()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/delete/<username>")
def delete_user(username):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM users WHERE username=?", (username,))
        conn.commit()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/update/<username>", methods=["GET", "POST"])
def update_user(username):
    if request.method == "POST":
        new_pass = request.form["password"]
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE users SET password=? WHERE username=?", (new_pass, username))
            conn.commit()
        return redirect(url_for("admin_dashboard"))

    return render_template("update_password.html", username=username)


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect(url_for("admin_login"))


# =====================================================================
#                          RUN APP
# =====================================================================
if __name__ == "__main__":
    app.run(debug=True)
