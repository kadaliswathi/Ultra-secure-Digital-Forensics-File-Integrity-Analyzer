# UltraSecure-DFTA (Digital Forensics & Threat Analyzer) - 2025

UltraSecure-DFTA is an advanced 2025-level Digital Forensics mini project designed for file integrity monitoring, forensic analysis, threat detection, and evidence reporting.  
This project includes both GUI and Flask-based web interfaces.

---

## 📌 Features (30+ Advanced Forensic Capabilities)

- File Integrity Monitoring (MD5/SHA256)
- Folder Change Monitoring (Watchdog)
- Baseline Hash Generation
- Integrity Verification System
- PDF Evidence Report Generation
- CSV Export Support
- Automated Screenshots
- Threat Analyzer (Suspicious File Detection)
- Backup System (Auto + Manual)
- Log Management System
- File Addition/Deletion Detection
- Modification Timestamp Monitoring
- Encryption Support (Hash Database Encryption)
- GUI Application (Tkinter)
- Flask Web Dashboard
- Upload-based Hash Verification
- Real-time Alerts
- Email Alert (Optional)
- File Type Recognition
- Metadata Extraction
- File Size Anomaly Detection
- Unauthorized Activity Tracking
- Hidden File Detection
- Dangerous Extensions Identification
- Tampered File Flagging
- Hash Database Storage (SQLite/JSON)
- Multi-folder Support
- Auto Folder Creation (logs/backups/uploads)
- Easy Deployment

---

## 📂 Project Structure

