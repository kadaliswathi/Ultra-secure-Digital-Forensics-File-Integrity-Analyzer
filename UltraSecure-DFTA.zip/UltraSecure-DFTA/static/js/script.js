document.addEventListener("DOMContentLoaded", () => {

    // ===== File upload toast notification =====
    const messageDiv = document.querySelector(".message");
    if (messageDiv) {
        messageDiv.style.opacity = 0;
        messageDiv.style.transform = "translateY(-10px)";
        messageDiv.style.transition = "opacity 0.6s ease, transform 0.6s ease";
        
        // Fade in with slide down
        setTimeout(() => {
            messageDiv.style.opacity = 1;
            messageDiv.style.transform = "translateY(0)";
        }, 100);

        // Auto fade out with slide up after 3s
        setTimeout(() => {
            messageDiv.style.opacity = 0;
            messageDiv.style.transform = "translateY(-10px)";
        }, 3000);
    }

    // ===== Dashboard report items animation =====
    const reportItems = document.querySelectorAll(".report-item");
    reportItems.forEach((item, index) => {
        item.style.opacity = 0;
        item.style.transform = "translateY(20px)";
        item.style.transition = `all 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55) ${index * 0.1}s`;

        setTimeout(() => {
            item.style.opacity = 1;
            item.style.transform = "translateY(0)";
        }, 100);
    });

    // ===== Button hover effects =====
    const buttons = document.querySelectorAll("button, .btn-download, .btn-dashboard, .back-btn");
    buttons.forEach(btn => {
        btn.style.transition = "all 0.2s ease-in-out";
        btn.addEventListener("mouseenter", () => {
            btn.style.transform = "scale(1.08)";
            btn.style.boxShadow = "0 4px 15px rgba(0,0,0,0.3)";
        });
        btn.addEventListener("mouseleave", () => {
            btn.style.transform = "scale(1)";
            btn.style.boxShadow = "none";
        });
    });

    // ===== Optional: Smooth fade for links on page load =====
    const links = document.querySelectorAll("a");
    links.forEach(link => {
        link.style.transition = "color 0.3s ease, transform 0.2s ease";
        link.addEventListener("mouseenter", () => {
            link.style.color = "#f1c40f";
            link.style.transform = "scale(1.05)";
        });
        link.addEventListener("mouseleave", () => {
            link.style.color = "";
            link.style.transform = "scale(1)";
        });
    });

});
